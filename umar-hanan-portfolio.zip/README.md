# Umar Hanan - Portfolio Website

🎨 **Creative Designer | Web Developer | Multi-Skilled Digital Artist**

## About

This is the portfolio website of Umar Hanan, showcasing skills in:
- Graphics Designing (Adobe Suite)
- UI/UX Design (Figma)
- Web Development (HTML, CSS, JavaScript)
- Game Development (Unity, C#)
- 2D Animation (Krita, Adobe Animate)
- Technical Skills & AI Tools

## Live Website

🌐 **Visit:** [https://your-username.github.io/portfolio](https://your-username.github.io/portfolio)

## Features

- ✨ Modern Pop Art design theme
- 📱 Fully responsive design
- 🎯 Smooth animations and transitions
- 📧 Contact form integration
- 📄 CV and certificate downloads
- 🔒 Security headers and HTTPS

## Technologies Used

- HTML5
- CSS3 (Grid, Flexbox, Animations)
- Vanilla JavaScript
- Font Awesome Icons
- Flaticon Icons

## Setup

1. Clone the repository
2. Open `index.html` in your browser
3. Customize content in HTML files
4. Update images in `/image` folder
5. Replace CV and certificate files

## Contact

- 📧 Email: uh568662@gmail.com
- 📱 WhatsApp: +92 323 1807785

---

© 2024 Umar Hanan. All rights reserved.
